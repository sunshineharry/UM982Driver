#ifndef POSE_H
#define POSE_H

typedef struct {
    double x;
    double x_std;
    double y;
    double y_std;
    double z;
    double z_std;
} Position;

typedef struct {
    double roll;
    double pitch;
    double yaw;
} Quaternion;

typedef struct {
    Position   position;
    Quaternion quaternion;
} Pose;

typedef struct {
    double vx;
    double vy;
    double vz;
} Twist;

typedef struct {
    Pose  pose;
    Twist twist;
} Odom;

#endif