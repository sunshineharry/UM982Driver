#include <math.h>
#include <memory.h>
#include <stdio.h>
#include "rtk.h"
#include "utm.h"




#define DEG_TO_RAD(degrees) ((degrees) * M_PI / 180.0)

// 检查pvt语句合法性
uint8_t rtk_pvt_sentence_check(const uint8_t *data, uint32_t data_length){
    if (data_length < sizeof(PVTSentence)) {
        return RTK_PVT_TOO_SHORT;
    }
    if (data[0] != 0xAA || data[1] != 0x44 || data[2] != 0xB5){
        return RTK_PVT_NO_SYNC;
    }
    return RTK_SUCCESS;
}

// 解析pvt语句
PVTSentence rtk_parse_pvt_data(const uint8_t *data, uint32_t data_length) {
    PVTSentence pvt;
    memcpy(&pvt, data, sizeof(PVTSentence));
    return pvt;
}

// 从pvt_sentence得到里程计信息（北东地坐标系）
Odom rtk_get_odom(PVTSentence* pvt_sentence){
    Odom odom;
    odom.pose.position = wgs84_to_utm(pvt_sentence->bestpos_lat, pvt_sentence->bestpos_lat,
                                 pvt_sentence->bestpos_lon, pvt_sentence->bestpos_lonstd,
                                 pvt_sentence->bestpos_hgt, pvt_sentence->bestpos_hgtstd);
    odom.pose.quaternion.roll  = 0;
    odom.pose.quaternion.pitch = DEG_TO_RAD(pvt_sentence->heading_pitch);
    odom.pose.quaternion.yaw   = DEG_TO_RAD(pvt_sentence->heading_degree);
    odom.twist.vx              = pvt_sentence->psrvel_north;
    odom.twist.vy              = pvt_sentence->psrvel_east;
    odom.twist.vz              = 0;
    return odom;
}