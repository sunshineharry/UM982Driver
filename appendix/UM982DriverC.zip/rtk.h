//
// Created by Harry on 2024/10/26.
//

#ifndef RTK_H
#define RTK_H

// 代码移植需要更改，适配自己的编译器
typedef float         float32_t;
typedef double        float64_t;
typedef unsigned char uint8_t;
typedef short         uint16_t;
typedef int           uint32_t;
//

#define RTK_SUCCESS        0
#define RTK_PVT_TOO_SHORT  1
#define RTK_PVT_NO_SYNC    2


# include "pose.h"



#pragma pack(push, 1)         // 强制编译器一字节对其

// 定义PVT信息的Header结构体
typedef struct {
    uint8_t  sync1;           // 同步字节 0xAA
    uint8_t  sync2;           // 同步字节 0x44
    uint8_t  sync3;           // 同步字节 0xB5
    uint8_t  cpuIdle;         // CPUIdle 0-100
    uint16_t messageID;       // 消息ID
    uint16_t messageLength;   // 消息长度
    uint8_t  timeRef;         // 时间系统 (GPST 或 BDST)
    uint8_t  timeStatus;      // 时间状态
    uint16_t wn;              // 时间周
    uint32_t ms;              // 周内秒（毫秒）
    uint32_t reserved;        // 保留字段
    uint8_t  version;         // 版本
    uint8_t  leapSec;         // 闰秒
    uint16_t delayMs;         // 数据输出延迟
} PVTHeader;

_Static_assert(sizeof(PVTHeader) == 24, "PVTHeader size is not 24 bytes, please check your compiler!");

// 定义PVT_Struct结构体，其中包含Header
typedef struct {
    PVTHeader header;               // 嵌套的Header结构体
    uint32_t  bestpos_type;         // bestpos类型，枚举值
    float32_t bestpos_hgt;          // 海拔高度，单位：米
    float64_t bestpos_lat;          // 纬度，单位：度
    float64_t bestpos_lon;          // 经度，单位：度
    float32_t bestpos_hgtstd;       // 高程标准差
    float32_t bestpos_latstd;       // 纬度标准差
    float32_t bestpos_lonstd;       // 经度标准差
    float32_t bestpos_diffage;      // 定位差分龄期
    uint32_t  psrpos_type;          // psrpos类型，枚举值
    float32_t psrpos_hgt;           // 平均海平面高度
    float64_t psrpos_lat;           // psrpos纬度
    float64_t psrpos_lon;           // psrpos经度
    float32_t undulation;           // 大地水准面差距
    uint8_t   bestpos_svs;          // 跟踪卫星数
    uint8_t   bestpos_solnsvs;      // 参与解算卫星数
    uint8_t   psrpos_svs;           // psr跟踪卫星数
    uint8_t   psrpos_solnsvs;       // psr参与解算卫星数
    float64_t psrvel_north;         // 北向速度，单位：米/秒
    float64_t psrvel_east;          // 东向速度，单位：米/秒
    float64_t psrvel_ground;        // 水平地面速度，单位：米/秒
    uint32_t  heading_type;         // 航向类型，枚举值
    float32_t heading_length;       // 基线长度
    float32_t heading_degree;       // 航向角度
    float32_t heading_pitch;        // 俯仰角
    uint8_t   heading_trackedsvs;   // 主天线跟踪卫星数
    uint8_t   heading_solnsvs;      // 参与解算卫星数
    uint8_t   heading_ggl1;         // L1频点参与解算的卫星数
    uint8_t   heading_ggl2;         // L1L2频点参与解算的卫星数
    float32_t gdop;                 // 几何精度因子
    float32_t pdop;                 // 位置精度因子
    float32_t hdop;                 // 水平精度因子
    float32_t htdop;                // 高程和时间精度因子
    float32_t tdop;                 // 时间精度因子
    float32_t cutoff;               // 截至高度角
    uint16_t  PRN_No;               // PRN数
    uint16_t  PRN_list[41];         // PRN列表（82字节）
    uint32_t  crc;                  // 32位CRC校验（仅ASCII和二进制）
} PVTSentence;

_Static_assert(sizeof(PVTSentence) == 252, "PVT_Struct size is not 252 bytes, please check your compiler!");

#pragma pack(pop)


uint8_t     rtk_pvt_sentence_check(const uint8_t *data, uint32_t data_length);
PVTSentence rtk_parse_pvt_data(const uint8_t *data, uint32_t data_length);
Odom        rtk_get_odom(PVTSentence* pvt_sentence);

#endif //RTK_H
