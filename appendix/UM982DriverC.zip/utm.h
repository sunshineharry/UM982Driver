//
// Created by Harry on 2024/10/29.
//

#ifndef GPS_UTM_H
#define GPS_UTM_H

#include "pose.h"

Position wgs84_to_utm(double lat, double lat_std, double lon, double lon_std, double alt, double alt_std);

#endif //GPS_UTM_H
