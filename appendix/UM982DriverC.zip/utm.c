//
// Created by Harry on 2024/10/29.
//

#include "utm.h"
#include "math.h"

#define LON_ZONE  50    // 北京UTM区域划分
// WGS84 参数
#define WGS84_A   6378137.0         // 主轴长度
#define WGS84_B   6356752.314245    // 副轴长度

#define DEG_TO_RAD(degrees) ((degrees) * M_PI / 180.0)


// 将WGS84坐标系转为UTM坐标系
Position wgs84_to_utm(double lat, double lat_std, double lon, double lon_std, double alt, double alt_std) {
    static const double a = WGS84_A/1000;
    static const double b = WGS84_B/1000;

    /// CONSTANTS
    static const double N0_n = 0;
    static const double N0_s = 1e4;
    static const double E0   = 5e2;
    static const double k0   = 0.9996;
    static const double f    = (a - b) / a;

    static const double n    = f / (2 - f);
    static const double n_2  = n   * n;
    static const double n_3  = n_2 * n;
    static const double n_4  = n_3 * n;
    static const double n_5  = n_4 * n;
    static const double n_6  = n_5 * n;
    static const double n_7  = n_6 * n;
    static const double n_8  = n_7 * n;
    static const double n_9  = n_8 * n;
    static const double n_10 = n_9 * n;

    static const int lon_zone = LON_ZONE;

    static const double lon_0 = DEG_TO_RAD(3 + 6 * (LON_ZONE - 1) - 180);



    static const double A = a / (1 + n) * (1 + n_2/4 + n_4/64 + n_6/256 + n_8*25.0/16384.0 + n_10*49.0/65536.0);
    static const double a1 = (1.0/2.0)*n - (2.0/3.0)*n_2 + (5.0/16.0)*n_3 + (41.0/180.0)*n_4 - (127.0/288.0)*n_5 + (7891.0/37800.0)*n_6 + (72161.0/387072.0)*n_7 - (18975107.0/50803200.0)*n_8 + (60193001.0/290304000.0)*n_9 + (134592031.0/1026432000.0)*n_10;
    static const double a2 = (13.0/48.0)*n_2 - (3.0/5.0)*n_3 + (557.0/1440.0)*n_4 + (281.0/630.0)*n_5 - (1983433.0/1935360.0)*n_6 + (13769.0/28800.0)*n_7 + (148003883.0/174182400.0)*n_8 - (705286231.0/465696000.0)*n_9 + (1703267974087.0/3218890752000.0)*n_10;
    static const double a3 = (61.0/240.0)*n_3 - (103.0/140.0)*n_4 + (15061.0/26880.0)*n_5 + (167603.0/181440.0)*n_6 - (67102379.0/29030400.0)*n_7 + (79682431.0/79833600.0)*n_8 + (6304945039.0/2128896000.0)*n_9 - (6601904925257.0/1307674368000.0)*n_10;
    static const double a4 = (49561.0/161280.0)*n_4 - (179.0/168.0)*n_5 + (6601661.0/7257600.0)*n_6 + (97445.0/49896.0)*n_7 - (40176129013.0/7664025600.0)*n_8 + (138471097.0/66528000.0)*n_9 + (48087451385201.0/5230697472000.0)*n_10;
    static const double a5 = (34729.0/80640.0)*n_5 - (3418889.0/1995840.0)*n_6 + (14644087.0/9123840.0)*n_7 + (2605413599.0/622702080.0)*n_8 - (31015475399.0/2583060480.0)*n_9 + (5820486440369.0/1307674368000.0)*n_10;
    static const double a6 = (212378941.0/319334400.0)*n_6 - (30705481.0/10378368.0)*n_7 + (175214326799.0/58118860800.0)*n_8 + (870492877.0/96096000.0)*n_9 - (1328004581729009.0/47823519744000.0)*n_10;
    static const double a7 = (1522256789.0/1383782400.0)*n_7 - (16759934899.0/3113510400.0)*n_8 + (1315149374443.0/221405184000.0)*n_9 + (71809987837451.0/3629463552000.0)*n_10;
    static const double a8 = (1424729850961.0/743921418240.0)*n_8 - (256783708069.0/25204608000.0)*n_9 + (2468749292989891.0/203249958912000.0)*n_10;
    static const double a9 = (21091646195357.0/6080126976000.0)*n_9 - (67196182138355857.0/3379030566912000.0)*n_10;
    static const double a10 = (77911515623232821.0/12014330904576000.0)*n_10;

    lat   = DEG_TO_RAD(lat);
    lon   = DEG_TO_RAD(lon);
    const double t = sinh(atanh(sin(lat)) - 2*sqrt(n)/(1+n) * atanh(2*sqrt(n)/(1+n)*sin(lat)));
    const double xi = atan(t/cos(lon-lon_0));
    const double eta = atanh(sin(lon-lon_0) / sqrt(1+t*t));

    const double N0 = (lat > 0 ? N0_n : N0_s);

    const double E = E0 + k0 * A * (eta + a1*cos(2*1*xi)*sinh(2*1*eta) + a2*cos(2*2*xi)*sinh(2*2*eta) + a3*cos(2*3*xi)*sinh(2*3*eta) + a4*cos(2*4*xi)*sinh(2*4*eta) + a5*cos(2*5*xi)*sinh(2*5*eta) + a6*cos(2*6*xi)*sinh(2*6*eta) + a7*cos(2*7*xi)*sinh(2*7*eta) + a8*cos(2*8*xi)*sinh(2*8*eta) + a9*cos(2*9*xi)*sinh(2*9*eta) + a10*cos(2*10*xi)*sinh(2*10*eta));
    const double N = N0 + k0 * A * (xi + a1*sin(2*1*xi)*cosh(2*1*eta) + a2*sin(2*2*xi)*cosh(2*2*eta) + a3*sin(2*3*xi)*cosh(2*3*eta) + a4*sin(2*4*xi)*cosh(2*4*eta) + a5*sin(2*5*xi)*cosh(2*5*eta) + a6*sin(2*6*xi)*cosh(2*6*eta) + a7*sin(2*7*xi)*cosh(2*7*eta) + a8*sin(2*8*xi)*cosh(2*8*eta) + a9*sin(2*9*xi)*cosh(2*9*eta) + a10*sin(2*10*xi)*cosh(2*10*eta));

    Position utm_ned_pos;
    utm_ned_pos.x      = 1000*N;
    utm_ned_pos.x_std  = lat_std;
    utm_ned_pos.y      = 1000*E;
    utm_ned_pos.y_std  = lon_std;
    utm_ned_pos.z      = -alt;
    utm_ned_pos.z_std  = alt_std;

    return utm_ned_pos;
}